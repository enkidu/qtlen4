#include "roster_manager.h"
QTlenRosterManager::QTlenRosterManager(QTlenRosterBox *rosterBox)
{
	dontShowOfflines = false;
	this->rosterBox = rosterBox;
};

int QTlenRosterManager::getIndexOf(QString jid)
{
	for ( int n = 0; n < (int)rosterItems.count(); n++ )
		if( rosterItems[n].jid == jid )
			return n;
	return -1;
};

QString QTlenRosterManager::getJidOf(QTreeWidgetItem* item)
{
	for ( int n = 0; n < (int)addedItems.count(); n++ )
		if( addedItems[n].item == item )
			return addedItems[n].jid;
	return "-1";
};

QString QTlenRosterManager::getJidOf(QString name)
{
	for ( int n = 0; n < (int)rosterItems.count(); n++ )
		if( rosterItems[n].name == name )
			return rosterItems[n].jid;
	return "-1";
};

int QTlenRosterManager::getIndexOfGroup(QString group)
{
	for ( int n = 0; n < (int)addedGroups.count(); n++ )
		if( addedGroups[n].group == group )
			return n;
	return -1;
};

int QTlenRosterManager::getIndexOfAddedGroup(QString group)
{
	for ( int n = 0; n < (int)addedGroups.count(); n++ )
		if( addedGroups[n].group == group )
			return n;
	return -1;
};

QTreeWidgetItem* QTlenRosterManager::getItemOfGroup(QString group)
{
	int index = getIndexOfAddedGroup(group);
	if ( index != -1)
		return addedGroups[index].item;
};

QString QTlenRosterManager::getNameOf(QString jid)
{
	for ( int n = 0; n < (int)rosterItems.count(); n++ )
		if( rosterItems[n].jid == jid )
			return rosterItems[n].name;
	return jid;
};

QString QTlenRosterManager::getGroupOf(QString jid)
{
	for ( int n = 0; n < (int)rosterItems.count(); n++ )
		if( rosterItems[n].jid == jid )
			return rosterItems[n].group;
	return "Tlen";
};

void QTlenRosterManager::beginRoster()
{
	 rosterItems.clear();
};

void QTlenRosterManager::addItem(QString jid, QString group, QString name, QString subscription)
{
	if (subscription != "remove")
	{
		if (getIndexOf(jid) != -1)
		{
			int index = getIndexOf(jid);
			if (name.isEmpty())
				rosterItems[index].name = jid;
			else
				rosterItems[index].name = name;
			if (group.isEmpty())
				rosterItems[index].group = "Tlen";
			else
				rosterItems[index].group = group;
			rosterItems[index].subscription = subscription;
		}
		else
		{
			RosterItem i;
			i.jid = jid;
			if (name.isEmpty())
				i.name = jid;
			else
				i.name = name;
			i.subscription = subscription;
			i.desc = QString::null;
			i.presence = Offline;
			if (group.isEmpty())
				i.group = "Tlen";
			else
				i.group = group;
			rosterItems.append(i);
		}
	}
	else
		rosterItems.removeAt(getIndexOf(jid));
	showRoster();
};

void QTlenRosterManager::presenceFrom(QString jid, QTlenPresence type, QString description)
{	
	if (getIndexOf(jid) != -1)
	{
		int index = getIndexOf(jid);
		rosterItems[index].presence = type;
		rosterItems[index].desc = description;
	}
	else
	{
		RosterItem i;
		i.jid = jid;
		i.name = jid;
		if (description.isEmpty())
			i.desc = "";
		else
			i.desc = description;
		i.subscription = "both";
		i.presence = type;
		i.group = "Tlen";
		rosterItems.append(i);
	}
	showRoster();
};

void QTlenRosterManager::showRoster()
{
	rosterBox->clear();
	qSort( rosterItems.begin(), rosterItems.end() );
	addedItems.clear();
	addedGroups.clear();
	AddedItem i;
	QTreeWidgetItem *node;
	for ( int n = 0; n < (int)rosterItems.count(); n++ )
	{
		if (!dontShowOfflines)
		{
			if(getIndexOfGroup(rosterItems[n].group) != -1)
			{
				node = addedGroups[getIndexOfGroup(rosterItems[n].group)].item;
			}
			else
			{
				node = new QTreeWidgetItem(rosterBox);
				QLabel *label = new QLabel(rosterItems[n].group, rosterBox);
				QFont font;
				font.setPointSize(7);
				label->setFont(font);
				label->setFrameShape(QFrame::StyledPanel);
				label->setFrameShadow(QFrame::Raised);
				label->setAlignment(Qt::AlignCenter);
				rosterBox->setItemWidget(node, 0, label);
				rosterBox->setItemExpanded(node, true);
				AddedGroup g;
				g.item = node;
				g.group = rosterItems[n].group;
				addedGroups.append(g);
			}
			i.item = rosterBox->addRosterItem(rosterItems[n].name, rosterItems[n].presence, rosterItems[n].desc, node);
			i.jid = rosterItems[n].jid;
			addedItems.append(i);
		}
		else if(rosterItems[n].presence != Offline)
		{
			if(getIndexOfGroup(rosterItems[n].group) != -1)
			{
				node = addedGroups[getIndexOfGroup(rosterItems[n].group)].item;
			}
			else
			{
				node = new QTreeWidgetItem(rosterBox);
				QLabel *label = new QLabel(rosterItems[n].group, rosterBox);
				QFont font;
				font.setPointSize(7);
				label->setFont(font);
				label->setFrameShape(QFrame::StyledPanel);
				label->setFrameShadow(QFrame::Raised);
				label->setAlignment(Qt::AlignCenter);
				rosterBox->setItemWidget(node, 0, label);
				rosterBox->setItemExpanded(node, true);
				AddedGroup g;
				g.item = node;
				g.group = rosterItems[n].group;
				addedGroups.append(g);
			}
			i.item = rosterBox->addRosterItem(rosterItems[n].name, rosterItems[n].presence, rosterItems[n].desc, node);
			i.jid = rosterItems[n].jid;
			addedItems.append(i);
		}
	}
};

void QTlenRosterManager::showOfflines(bool yesno)
{
	dontShowOfflines = !yesno;
	showRoster();
};

void QTlenRosterManager::deleteItem(QTreeWidgetItem* item)
{
	if (getJidOf(item) != "-1")
	{
		rosterItems.removeAt(getIndexOf(getJidOf(item)));
		showRoster();
	}
};