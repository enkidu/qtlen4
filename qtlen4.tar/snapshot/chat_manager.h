#include <QtCore/QtCore>
#include "chat.h"
#include "roster_manager.h"
#include "systrayicon.h"
class QTlenChatManager: public QObject
{
	Q_OBJECT
	public:
		QTlenChatManager(QTlenRosterManager * roster);
		~QTlenChatManager(){};
		struct ChatItem
		{
			QString 		jid;
			QTlenChatWindow		*widget;
		};
		int			findIndexOf(QString);
		void			setTrayIcon(QTlenTrayIcon* icon){this->sysIcon = icon;};
		QTlenRosterManager	*roster;
	private:
		QList<ChatItem>		chats;
		QString 		myNick;
		QTlenTrayIcon*		sysIcon;
	public slots:
		void			showMessage(QString, QString, QDateTime);
		void			detachWidget(QString);
		void			openChat(QString);
		void			setMyInfo(QString);
		void			messageProxy(QString, QString);
		void			typingStarted(QString);
		void			typingStopped(QString);
		QTlenChatWindow*	createWindow(QString);
	signals:
		void			sendMessage(QString, QString);
};