/********************************************************************************
** Form generated from reading ui file 'debug.ui'
**
** Created: Fri Feb 6 01:07:31 2009
**      by: Qt User Interface Compiler version 4.4.3
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_DEBUG_H
#define UI_DEBUG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGridLayout>
#include <QtGui/QTextEdit>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_debugWindow
{
public:
    QGridLayout *gridLayout;
    QTextEdit *debug_console;

    void setupUi(QWidget *debugWindow)
    {
    if (debugWindow->objectName().isEmpty())
        debugWindow->setObjectName(QString::fromUtf8("debugWindow"));
    debugWindow->resize(338, 295);
    gridLayout = new QGridLayout(debugWindow);
    gridLayout->setSpacing(0);
    gridLayout->setMargin(0);
    gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
    debug_console = new QTextEdit(debugWindow);
    debug_console->setObjectName(QString::fromUtf8("debug_console"));
    debug_console->setStyleSheet(QString::fromUtf8("div.parsed\n"
"{\n"
"	font-weight: bold;\n"
"	color: #00f;\n"
"}\n"
"div.sent\n"
"{\n"
"	font-weight: bold;\n"
"	color: #0e0;\n"
"}\n"
"div.unparsed\n"
"{\n"
"	font-weight:bold;\n"
"	color: #d00;\n"
"}"));
    debug_console->setTextInteractionFlags(Qt::TextSelectableByKeyboard|Qt::TextSelectableByMouse);

    gridLayout->addWidget(debug_console, 0, 0, 1, 1);


    retranslateUi(debugWindow);

    QMetaObject::connectSlotsByName(debugWindow);
    } // setupUi

    void retranslateUi(QWidget *debugWindow)
    {
    debugWindow->setWindowTitle(QApplication::translate("debugWindow", "XML", 0, QApplication::UnicodeUTF8));
    debug_console->setHtml(QApplication::translate("debugWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'DejaVu Sans'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"></p></body></html>", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(debugWindow);
    } // retranslateUi

};

namespace Ui {
    class debugWindow: public Ui_debugWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DEBUG_H
