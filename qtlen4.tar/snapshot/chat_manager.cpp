#include "chat_manager.h"

QTlenChatManager::QTlenChatManager(QTlenRosterManager * roster)
{
	this->roster = roster;
};

int QTlenChatManager::findIndexOf(QString jid)
{
	for ( int n = 0; n < (int)chats.count(); n++ )
		if( chats[n].jid == jid )
			return n;
	return -1;
};

QTlenChatWindow* QTlenChatManager::createWindow(QString jid)
{
	ChatItem i;
	i.jid = jid;
	QTlenChatWindow *widget = new QTlenChatWindow();
	widget->setContactInfo(jid, roster->getNameOf(jid));
	widget->setMyInfo(myNick);
	widget->show();
	i.widget=widget;
	chats.append(i);
	connect(widget,	SIGNAL(widgetClosed(QString)),	this,	SLOT(detachWidget(QString)));
	connect(widget, SIGNAL(message(QString, QString)),	this,	SLOT(messageProxy(QString, QString)));
	return widget;
};

void QTlenChatManager::showMessage(QString jid, QString body, QDateTime stamp)
{
	if (findIndexOf(jid) != -1)
	{
		chats[findIndexOf(jid)].widget->showMessage(body, stamp);
		chats[findIndexOf(jid)].widget->raise();
	}
	else
	{
		sysIcon->showMessage(QString::fromUtf8("Nowa rozmowa z ") + roster->getNameOf(jid), body);
		QTlenChatWindow *widget = createWindow(jid);
		widget->showMessage(body, stamp);
		widget->setTyping(false);
	}
};

void QTlenChatManager::detachWidget(QString jid)
{
	if (findIndexOf(jid) != -1)
	{
		chats.removeAt(findIndexOf(jid));
	}
};

void QTlenChatManager::openChat(QString jid)
{
	if ((findIndexOf(jid) == -1) and jid != "-1")
	{
		createWindow(jid);
	}
};

void QTlenChatManager::typingStarted(QString jid)
{
	if (findIndexOf(jid) != -1)
		chats[findIndexOf(jid)].widget->setTyping(true);
	else
	{
		sysIcon->showMessage(QString::fromUtf8("Nowa rozmowa z ") + roster->getNameOf(jid), QString("..."));
		QTlenChatWindow *widget = createWindow(jid);
		widget->setTyping(true);
	}
};

void QTlenChatManager::typingStopped(QString jid)
{
	if (findIndexOf(jid) != -1)
		chats[findIndexOf(jid)].widget->setTyping(false);
};

void QTlenChatManager::setMyInfo(QString nick)
{
	myNick = nick; //może pobierać to ze wskaźnika do ustawień?
};

void QTlenChatManager::messageProxy(QString jid, QString body)
{
	emit sendMessage(jid, body);
};