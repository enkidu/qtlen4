#include "settings_dialog.h"

QTlenConfigDialog::QTlenConfigDialog(QWidget * parent):QToolBox(parent)
{
	ui.setupUi(this);
	settings = new QSettings(QDir::homePath() + "/.qtlen4/config", QSettings::IniFormat);
	ui.le_login->setText(settings->value("/connection/username", "").toString());
	ui.le_password->setText(settings->value("/connection/password", "").toString());
	ui.cb_autoConnect->setChecked(settings->value("/behaviour/autoconnect", false).toBool());
	ui.cb_showOfflines->setChecked(settings->value("/behaviour/showofflines", false).toBool());
	ui.le_nick->setText(settings->value("/preferences/nick", "").toString());
	connect(ui.pb_myColor,		SIGNAL(clicked()),	this,	SLOT(setMyColor()));
	connect(ui.pb_myBg,		SIGNAL(clicked()),	this,	SLOT(setMyBg()));
	connect(ui.pb_chatColor,	SIGNAL(clicked()),	this,	SLOT(setChatColor()));
	connect(ui.pb_chatBg,		SIGNAL(clicked()),	this,	SLOT(setChatBg()));
	changed = false;
};

void QTlenConfigDialog::closeEvent(QCloseEvent *event)
{
	//zapisujemy i puszczamy sygnały ewentualnie
	if (ui.le_login->text() != settings->value("/connection/username", "").toString())
		changed = true;
	if (ui.le_password->text() != settings->value("/connection/password", "").toString())
		changed = true;
	if (ui.cb_autoConnect->isTristate() != settings->value("/behaviour/autoconnect", false).toBool())
		changed = true;
	if (ui.cb_showOfflines->isTristate() != settings->value("/behaviour/showofflines", false).toBool())
		changed = true;
	if (ui.le_nick->text() != settings->value("/preferences/nick", "").toString())
		changed = true;
	//jeżeli zmieniło się hasło lub nazwa użytkownika, puszczamy osobny sygnał,
	//czy pozwalamy, by główny obiekt się tym zajął?
	settings->setValue("/connection/username", ui.le_login->text());
	settings->setValue("/connection/password", ui.le_password->text());
	settings->setValue("/behaviour/autoconnect", ui.cb_autoConnect->isChecked());
	settings->setValue("/behaviour/showofflines", ui.cb_showOfflines->isChecked());
	settings->setValue("/preferences/nick", ui.le_nick->text());
	if (changed)
		emit configChanged();
	event->accept();
};

void QTlenConfigDialog::setMyColor()
{
	QColor color = QColorDialog::getColor(QColor(settings->value("/preferences/sent/color", "#000000").toString()), this);
	if (color.isValid())
		settings->setValue("/preferences/sent/color", color.name());
};

void QTlenConfigDialog::setMyBg()
{
	QColor color = QColorDialog::getColor(QColor(settings->value("/preferences/sent/bground", "#ffffff").toString()), this);
	if (color.isValid())
		settings->setValue("/preferences/sent/bground", color.name());
};

void QTlenConfigDialog::setChatColor()
{
	QColor color = QColorDialog::getColor(QColor(settings->value("/preferences/received/color", "#000000").toString()), this);
	if (color.isValid())
		settings->setValue("/preferences/received/color", color.name());
};

void QTlenConfigDialog::setChatBg()
{
	QColor color = QColorDialog::getColor(QColor(settings->value("/preferences/received/bground", "#ffffff").toString()), this);
	if (color.isValid())
		settings->setValue("/preferences/received/bground", color.name());
};