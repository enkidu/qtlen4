#include "chat_edit.h"

QTlenTextEdit::QTlenTextEdit(QWidget * parent): QTextEdit(parent)
{
};

void QTlenTextEdit::keyPressEvent( QKeyEvent * e )
{
	if(( e->key() == Qt::Key_Return || e->key() == Qt::Key_Enter ) && e->modifiers() != Qt::ShiftModifier)
		emit returnPressed();
	else
		QTextEdit::keyPressEvent(e);
};