/********************************************************************************
** Form generated from reading ui file 'config.ui'
**
** Created: Fri Feb 6 15:41:10 2009
**      by: Qt User Interface Compiler version 4.4.3
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_CONFIG_H
#define UI_CONFIG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QFormLayout>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QScrollArea>
#include <QtGui/QToolBox>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_configDialog
{
public:
    QWidget *page;
    QFormLayout *formLayout;
    QLabel *label;
    QLineEdit *le_login;
    QLabel *label_2;
    QLineEdit *le_password;
    QWidget *strona_2;
    QFormLayout *formLayout_2;
    QCheckBox *cb_autoConnect;
    QLabel *label_3;
    QComboBox *cb_defaultState;
    QCheckBox *cb_showOfflines;
    QWidget *strona_4;
    QGridLayout *gridLayout;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QVBoxLayout *verticalLayout;
    QGroupBox *groupBox;
    QFormLayout *formLayout_4;
    QLabel *label_5;
    QLineEdit *le_nick;
    QLabel *label_7;
    QLabel *label_6;
    QPushButton *pb_myColor;
    QPushButton *pb_myBg;
    QGroupBox *groupBox_2;
    QFormLayout *formLayout_5;
    QLabel *label_8;
    QCheckBox *cb_useJID;
    QPushButton *pb_chatColor;
    QPushButton *pb_chatBg;
    QLabel *label_9;
    QWidget *strona;
    QWidget *strona_3;
    QFormLayout *formLayout_3;
    QCheckBox *cb_showInbounds;
    QLabel *label_4;
    QComboBox *cb_inboundsType;
    QCheckBox *cb_showOutbounds;

    void setupUi(QToolBox *configDialog)
    {
    if (configDialog->objectName().isEmpty())
        configDialog->setObjectName(QString::fromUtf8("configDialog"));
    configDialog->resize(363, 328);
    page = new QWidget();
    page->setObjectName(QString::fromUtf8("page"));
    page->setGeometry(QRect(0, 0, 96, 58));
    formLayout = new QFormLayout(page);
    formLayout->setObjectName(QString::fromUtf8("formLayout"));
    formLayout->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
    formLayout->setHorizontalSpacing(4);
    formLayout->setVerticalSpacing(4);
    formLayout->setContentsMargins(6, 0, 6, 0);
    label = new QLabel(page);
    label->setObjectName(QString::fromUtf8("label"));

    formLayout->setWidget(0, QFormLayout::LabelRole, label);

    le_login = new QLineEdit(page);
    le_login->setObjectName(QString::fromUtf8("le_login"));

    formLayout->setWidget(0, QFormLayout::FieldRole, le_login);

    label_2 = new QLabel(page);
    label_2->setObjectName(QString::fromUtf8("label_2"));

    formLayout->setWidget(1, QFormLayout::LabelRole, label_2);

    le_password = new QLineEdit(page);
    le_password->setObjectName(QString::fromUtf8("le_password"));
    le_password->setEchoMode(QLineEdit::Password);

    formLayout->setWidget(1, QFormLayout::FieldRole, le_password);

    configDialog->addItem(page, QApplication::translate("configDialog", "Po\305\202\304\205czenie", 0, QApplication::UnicodeUTF8));
    strona_2 = new QWidget();
    strona_2->setObjectName(QString::fromUtf8("strona_2"));
    strona_2->setGeometry(QRect(0, 0, 284, 80));
    formLayout_2 = new QFormLayout(strona_2);
    formLayout_2->setObjectName(QString::fromUtf8("formLayout_2"));
    formLayout_2->setHorizontalSpacing(4);
    formLayout_2->setVerticalSpacing(4);
    formLayout_2->setContentsMargins(6, 0, 6, 0);
    cb_autoConnect = new QCheckBox(strona_2);
    cb_autoConnect->setObjectName(QString::fromUtf8("cb_autoConnect"));

    formLayout_2->setWidget(0, QFormLayout::FieldRole, cb_autoConnect);

    label_3 = new QLabel(strona_2);
    label_3->setObjectName(QString::fromUtf8("label_3"));

    formLayout_2->setWidget(1, QFormLayout::LabelRole, label_3);

    cb_defaultState = new QComboBox(strona_2);
    QIcon icon;
    icon.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/16x16/online.png")), QIcon::Normal, QIcon::Off);
    cb_defaultState->addItem(icon, QString());
    QIcon icon1;
    icon1.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/16x16/chatty.png")), QIcon::Normal, QIcon::Off);
    cb_defaultState->addItem(icon1, QString());
    QIcon icon2;
    icon2.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/16x16/away.png")), QIcon::Normal, QIcon::Off);
    cb_defaultState->addItem(icon2, QString());
    QIcon icon3;
    icon3.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/16x16/xa.png")), QIcon::Normal, QIcon::Off);
    cb_defaultState->addItem(icon3, QString());
    QIcon icon4;
    icon4.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/16x16/dnd.png")), QIcon::Normal, QIcon::Off);
    cb_defaultState->addItem(icon4, QString());
    QIcon icon5;
    icon5.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/16x16/invisible.png")), QIcon::Normal, QIcon::Off);
    cb_defaultState->addItem(icon5, QString());
    cb_defaultState->addItem(QString());
    cb_defaultState->setObjectName(QString::fromUtf8("cb_defaultState"));
    cb_defaultState->setEnabled(false);

    formLayout_2->setWidget(1, QFormLayout::FieldRole, cb_defaultState);

    cb_showOfflines = new QCheckBox(strona_2);
    cb_showOfflines->setObjectName(QString::fromUtf8("cb_showOfflines"));
    QIcon icon6;
    icon6.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/view-user-offline-kopete.png")), QIcon::Normal, QIcon::Off);
    cb_showOfflines->setIcon(icon6);

    formLayout_2->setWidget(2, QFormLayout::FieldRole, cb_showOfflines);

    configDialog->addItem(strona_2, QApplication::translate("configDialog", "Zachowanie", 0, QApplication::UnicodeUTF8));
    strona_4 = new QWidget();
    strona_4->setObjectName(QString::fromUtf8("strona_4"));
    strona_4->setGeometry(QRect(0, 0, 363, 203));
    gridLayout = new QGridLayout(strona_4);
    gridLayout->setMargin(0);
    gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
    scrollArea = new QScrollArea(strona_4);
    scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
    scrollArea->setWidgetResizable(true);
    scrollAreaWidgetContents = new QWidget();
    scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
    scrollAreaWidgetContents->setGeometry(QRect(0, -79, 344, 278));
    verticalLayout = new QVBoxLayout(scrollAreaWidgetContents);
    verticalLayout->setMargin(0);
    verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
    groupBox = new QGroupBox(scrollAreaWidgetContents);
    groupBox->setObjectName(QString::fromUtf8("groupBox"));
    formLayout_4 = new QFormLayout(groupBox);
    formLayout_4->setObjectName(QString::fromUtf8("formLayout_4"));
    formLayout_4->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
    label_5 = new QLabel(groupBox);
    label_5->setObjectName(QString::fromUtf8("label_5"));

    formLayout_4->setWidget(0, QFormLayout::LabelRole, label_5);

    le_nick = new QLineEdit(groupBox);
    le_nick->setObjectName(QString::fromUtf8("le_nick"));

    formLayout_4->setWidget(0, QFormLayout::FieldRole, le_nick);

    label_7 = new QLabel(groupBox);
    label_7->setObjectName(QString::fromUtf8("label_7"));

    formLayout_4->setWidget(4, QFormLayout::LabelRole, label_7);

    label_6 = new QLabel(groupBox);
    label_6->setObjectName(QString::fromUtf8("label_6"));

    formLayout_4->setWidget(3, QFormLayout::LabelRole, label_6);

    pb_myColor = new QPushButton(groupBox);
    pb_myColor->setObjectName(QString::fromUtf8("pb_myColor"));

    formLayout_4->setWidget(3, QFormLayout::FieldRole, pb_myColor);

    pb_myBg = new QPushButton(groupBox);
    pb_myBg->setObjectName(QString::fromUtf8("pb_myBg"));

    formLayout_4->setWidget(4, QFormLayout::FieldRole, pb_myBg);


    verticalLayout->addWidget(groupBox);

    groupBox_2 = new QGroupBox(scrollAreaWidgetContents);
    groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
    formLayout_5 = new QFormLayout(groupBox_2);
    formLayout_5->setObjectName(QString::fromUtf8("formLayout_5"));
    label_8 = new QLabel(groupBox_2);
    label_8->setObjectName(QString::fromUtf8("label_8"));

    formLayout_5->setWidget(1, QFormLayout::LabelRole, label_8);

    cb_useJID = new QCheckBox(groupBox_2);
    cb_useJID->setObjectName(QString::fromUtf8("cb_useJID"));

    formLayout_5->setWidget(0, QFormLayout::FieldRole, cb_useJID);

    pb_chatColor = new QPushButton(groupBox_2);
    pb_chatColor->setObjectName(QString::fromUtf8("pb_chatColor"));

    formLayout_5->setWidget(1, QFormLayout::FieldRole, pb_chatColor);

    pb_chatBg = new QPushButton(groupBox_2);
    pb_chatBg->setObjectName(QString::fromUtf8("pb_chatBg"));

    formLayout_5->setWidget(2, QFormLayout::FieldRole, pb_chatBg);

    label_9 = new QLabel(groupBox_2);
    label_9->setObjectName(QString::fromUtf8("label_9"));

    formLayout_5->setWidget(2, QFormLayout::LabelRole, label_9);


    verticalLayout->addWidget(groupBox_2);

    scrollArea->setWidget(scrollAreaWidgetContents);

    gridLayout->addWidget(scrollArea, 0, 0, 1, 1);

    configDialog->addItem(strona_4, QApplication::translate("configDialog", "Wygl\304\205d", 0, QApplication::UnicodeUTF8));
    strona = new QWidget();
    strona->setObjectName(QString::fromUtf8("strona"));
    strona->setGeometry(QRect(0, 0, 96, 26));
    configDialog->addItem(strona, QApplication::translate("configDialog", "Proxy", 0, QApplication::UnicodeUTF8));
    strona_3 = new QWidget();
    strona_3->setObjectName(QString::fromUtf8("strona_3"));
    strona_3->setGeometry(QRect(0, 0, 349, 102));
    formLayout_3 = new QFormLayout(strona_3);
    formLayout_3->setObjectName(QString::fromUtf8("formLayout_3"));
    cb_showInbounds = new QCheckBox(strona_3);
    cb_showInbounds->setObjectName(QString::fromUtf8("cb_showInbounds"));

    formLayout_3->setWidget(0, QFormLayout::FieldRole, cb_showInbounds);

    label_4 = new QLabel(strona_3);
    label_4->setObjectName(QString::fromUtf8("label_4"));

    formLayout_3->setWidget(1, QFormLayout::LabelRole, label_4);

    cb_inboundsType = new QComboBox(strona_3);
    cb_inboundsType->setObjectName(QString::fromUtf8("cb_inboundsType"));
    cb_inboundsType->setEnabled(false);

    formLayout_3->setWidget(1, QFormLayout::FieldRole, cb_inboundsType);

    cb_showOutbounds = new QCheckBox(strona_3);
    cb_showOutbounds->setObjectName(QString::fromUtf8("cb_showOutbounds"));

    formLayout_3->setWidget(2, QFormLayout::FieldRole, cb_showOutbounds);

    configDialog->addItem(strona_3, QApplication::translate("configDialog", "Konsola XML", 0, QApplication::UnicodeUTF8));

#ifndef QT_NO_SHORTCUT
    label->setBuddy(le_login);
    label_2->setBuddy(le_password);
#endif // QT_NO_SHORTCUT


    retranslateUi(configDialog);
    QObject::connect(cb_autoConnect, SIGNAL(toggled(bool)), cb_defaultState, SLOT(setEnabled(bool)));
    QObject::connect(cb_showInbounds, SIGNAL(toggled(bool)), cb_inboundsType, SLOT(setEnabled(bool)));

    configDialog->setCurrentIndex(2);
    configDialog->layout()->setSpacing(0);


    QMetaObject::connectSlotsByName(configDialog);
    } // setupUi

    void retranslateUi(QToolBox *configDialog)
    {
    configDialog->setWindowTitle(QApplication::translate("configDialog", "QTlen4 - Konfiguracja", 0, QApplication::UnicodeUTF8));

#ifndef QT_NO_ACCESSIBILITY
    page->setAccessibleName(QString());
#endif // QT_NO_ACCESSIBILITY

    label->setText(QApplication::translate("configDialog", "Login", 0, QApplication::UnicodeUTF8));
    label_2->setText(QApplication::translate("configDialog", "Has\305\202o", 0, QApplication::UnicodeUTF8));
    configDialog->setItemText(configDialog->indexOf(page), QApplication::translate("configDialog", "Po\305\202\304\205czenie", 0, QApplication::UnicodeUTF8));
    cb_autoConnect->setText(QApplication::translate("configDialog", "Po\305\202\304\205cz po uruchomieniu", 0, QApplication::UnicodeUTF8));
    label_3->setText(QApplication::translate("configDialog", "Domy\305\233lny status", 0, QApplication::UnicodeUTF8));
    cb_defaultState->setItemText(0, QApplication::translate("configDialog", "Dost\304\231pny", 0, QApplication::UnicodeUTF8));
    cb_defaultState->setItemText(1, QApplication::translate("configDialog", "Porozmawiajmy", 0, QApplication::UnicodeUTF8));
    cb_defaultState->setItemText(2, QApplication::translate("configDialog", "Zaraz wracam", 0, QApplication::UnicodeUTF8));
    cb_defaultState->setItemText(3, QApplication::translate("configDialog", "Wracam p\303\263\305\272niej", 0, QApplication::UnicodeUTF8));
    cb_defaultState->setItemText(4, QApplication::translate("configDialog", "Zaj\304\231ty", 0, QApplication::UnicodeUTF8));
    cb_defaultState->setItemText(5, QApplication::translate("configDialog", "Niewidoczny", 0, QApplication::UnicodeUTF8));
    cb_defaultState->setItemText(6, QApplication::translate("configDialog", "--Poprzedni", 0, QApplication::UnicodeUTF8));

    cb_showOfflines->setText(QApplication::translate("configDialog", "Pokazuj nieobecnych", 0, QApplication::UnicodeUTF8));
    configDialog->setItemText(configDialog->indexOf(strona_2), QApplication::translate("configDialog", "Zachowanie", 0, QApplication::UnicodeUTF8));
    groupBox->setTitle(QApplication::translate("configDialog", "Wys\305\202ane", 0, QApplication::UnicodeUTF8));
    label_5->setText(QApplication::translate("configDialog", "Nick", 0, QApplication::UnicodeUTF8));
    label_7->setText(QApplication::translate("configDialog", "Kolor t\305\202a", 0, QApplication::UnicodeUTF8));
    label_6->setText(QApplication::translate("configDialog", "Kolor tekstu", 0, QApplication::UnicodeUTF8));
    pb_myColor->setText(QApplication::translate("configDialog", "Wybierz", 0, QApplication::UnicodeUTF8));
    pb_myBg->setText(QApplication::translate("configDialog", "Wybierz", 0, QApplication::UnicodeUTF8));
    groupBox_2->setTitle(QApplication::translate("configDialog", "Odebrane", 0, QApplication::UnicodeUTF8));
    label_8->setText(QApplication::translate("configDialog", "Kolor tekstu", 0, QApplication::UnicodeUTF8));
    cb_useJID->setText(QApplication::translate("configDialog", "U\305\274ywaj ID zamiast nazwy kontaktu", 0, QApplication::UnicodeUTF8));
    pb_chatColor->setText(QApplication::translate("configDialog", "Wybierz", 0, QApplication::UnicodeUTF8));
    pb_chatBg->setText(QApplication::translate("configDialog", "Wybierz", 0, QApplication::UnicodeUTF8));
    label_9->setText(QApplication::translate("configDialog", "Kolor t\305\202a", 0, QApplication::UnicodeUTF8));
    configDialog->setItemText(configDialog->indexOf(strona_4), QApplication::translate("configDialog", "Wygl\304\205d", 0, QApplication::UnicodeUTF8));
    configDialog->setItemText(configDialog->indexOf(strona), QApplication::translate("configDialog", "Proxy", 0, QApplication::UnicodeUTF8));
    cb_showInbounds->setText(QApplication::translate("configDialog", "Pokazuj pakiety przychodz\304\205ce", 0, QApplication::UnicodeUTF8));
    label_4->setText(QApplication::translate("configDialog", "Pokazywane pakiety", 0, QApplication::UnicodeUTF8));
    cb_inboundsType->clear();
    cb_inboundsType->insertItems(0, QStringList()
     << QApplication::translate("configDialog", "Wszystkie", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("configDialog", "Tylko rozpoznane", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("configDialog", "Tylko nierozpoznane", 0, QApplication::UnicodeUTF8)
    );
    cb_showOutbounds->setText(QApplication::translate("configDialog", "Pokazuj pakiety wychodz\304\205ce", 0, QApplication::UnicodeUTF8));
    configDialog->setItemText(configDialog->indexOf(strona_3), QApplication::translate("configDialog", "Konsola XML", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(configDialog);
    } // retranslateUi

};

namespace Ui {
    class configDialog: public Ui_configDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONFIG_H
