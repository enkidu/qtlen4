#include "chat.h"
#include "ui_chat.h"

QTlenChatWindow::QTlenChatWindow(QWidget * parent, Qt::WFlags f):QMainWindow(parent, f)
{
	ui.setupUi(this);
	connect(ui.pb_chatSend,		SIGNAL(clicked()),		this,	SLOT(sendMessage()));
	connect(ui.te_chatInput,	SIGNAL(returnPressed()),	this,	SLOT(sendMessage()));
	ui.te_chatWindow->setReadOnly(true);
	ui.actionTyping->setEnabled(false);
	settings = new QSettings(QDir::homePath() + "/.qtlen4/config", QSettings::IniFormat);
	myColor = settings->value("/preferences/sent/color", "#000000").toString();
	myBg = settings->value("/preferences/sent/bground", "#ffffff").toString();
	chatColor = settings->value("/preferences/received/color", "#000000").toString();
	chatBg = settings->value("/preferences/received/bground", "#ffffff").toString();
	vertScroll = ui.te_chatWindow->verticalScrollBar();
};

void QTlenChatWindow::setContactInfo(QString jid, QString name)
{
	this->jid=jid;
	this->nick=name;
	setWindowTitle(name);
}

void QTlenChatWindow::showMessage(QString body, QDateTime stamp)
{
	ui.te_chatWindow->moveCursor(QTextCursor::End);
	ui.te_chatWindow->insertHtml(formatMessage(stamp, nick, body, chatColor, chatBg));
	ui.te_chatWindow->insertHtml("<br>");
	vertScroll->setValue(vertScroll->maximum());
};

void QTlenChatWindow::closeEvent(QCloseEvent *event)
{
	event->accept();
	emit widgetClosed(jid);
};

void QTlenChatWindow::sendMessage()
{
	emit message(jid, ui.te_chatInput->toPlainText());
	ui.te_chatWindow->moveCursor(QTextCursor::End);
	ui.te_chatWindow->insertHtml(formatMessage(QDateTime::currentDateTime(), myNick, ui.te_chatInput->toPlainText(), myColor, myBg));
	ui.te_chatWindow->insertHtml("<br>");
	vertScroll->setValue(vertScroll->maximum());
	ui.te_chatInput->clear();
};

void QTlenChatWindow::setTyping(bool yesno)
{
	ui.actionTyping->setEnabled(yesno);
};

void QTlenChatWindow::setMyInfo(QString nick)
{
	myNick = nick;
};

QString QTlenChatWindow::formatMessage(QDateTime time, QString nick, QString body, QString color, QString bground)
{
	body = Qt::escape(body);
	body.replace("\n\r", "<br>");
	body.replace("\n", "<br>");
	body.replace("\r", "<br>");
	QString format("<div style=\"color: %1;\"><b>%2 %3</b><br>%4</div>");
	return format.arg(color, time.time().toString(), nick, body);
};