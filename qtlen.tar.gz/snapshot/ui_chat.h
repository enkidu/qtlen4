/********************************************************************************
** Form generated from reading ui file 'chat.ui'
**
** Created: Wed Jan 28 11:41:29 2009
**      by: Qt User Interface Compiler version 4.4.3
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_CHAT_H
#define UI_CHAT_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGridLayout>
#include <QtGui/QMainWindow>
#include <QtGui/QPushButton>
#include <QtGui/QTextEdit>
#include <QtGui/QToolBar>
#include <QtGui/QWidget>
#include "chat_edit.h"

QT_BEGIN_NAMESPACE

class Ui_chatWindow
{
public:
    QAction *actionTyping;
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QTextEdit *te_chatWindow;
    QTextEdit *te_chatInput;
    QPushButton *pb_chatSend;
    QToolBar *toolBar;

    void setupUi(QMainWindow *chatWindow)
    {
    if (chatWindow->objectName().isEmpty())
        chatWindow->setObjectName(QString::fromUtf8("chatWindow"));
    chatWindow->resize(343, 449);
    actionTyping = new QAction(chatWindow);
    actionTyping->setObjectName(QString::fromUtf8("actionTyping"));
    QIcon icon;
    icon.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/draw-freehand.png")), QIcon::Normal, QIcon::Off);
    actionTyping->setIcon(icon);
    centralwidget = new QWidget(chatWindow);
    centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
    gridLayout = new QGridLayout(centralwidget);
    gridLayout->setSpacing(0);
    gridLayout->setMargin(0);
    gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
    te_chatWindow = new QTextEdit(centralwidget);
    te_chatWindow->setObjectName(QString::fromUtf8("te_chatWindow"));
    QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    sizePolicy.setHorizontalStretch(0);
    sizePolicy.setVerticalStretch(3);
    sizePolicy.setHeightForWidth(te_chatWindow->sizePolicy().hasHeightForWidth());
    te_chatWindow->setSizePolicy(sizePolicy);
    te_chatWindow->setReadOnly(true);

    gridLayout->addWidget(te_chatWindow, 0, 0, 1, 1);

    te_chatInput = new QTlenTextEdit(centralwidget);
    te_chatInput->setObjectName(QString::fromUtf8("te_chatInput"));
    QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
    sizePolicy1.setHorizontalStretch(0);
    sizePolicy1.setVerticalStretch(1);
    sizePolicy1.setHeightForWidth(te_chatInput->sizePolicy().hasHeightForWidth());
    te_chatInput->setSizePolicy(sizePolicy1);

    gridLayout->addWidget(te_chatInput, 1, 0, 1, 1);

    pb_chatSend = new QPushButton(centralwidget);
    pb_chatSend->setObjectName(QString::fromUtf8("pb_chatSend"));
    pb_chatSend->setMaximumSize(QSize(60, 16777215));
    pb_chatSend->setLayoutDirection(Qt::RightToLeft);

    gridLayout->addWidget(pb_chatSend, 2, 0, 1, 1);

    chatWindow->setCentralWidget(centralwidget);
    toolBar = new QToolBar(chatWindow);
    toolBar->setObjectName(QString::fromUtf8("toolBar"));
    toolBar->setLayoutDirection(Qt::RightToLeft);
    toolBar->setMovable(false);
    toolBar->setAllowedAreas(Qt::TopToolBarArea);
    chatWindow->addToolBar(Qt::TopToolBarArea, toolBar);

    toolBar->addAction(actionTyping);

    retranslateUi(chatWindow);

    QMetaObject::connectSlotsByName(chatWindow);
    } // setupUi

    void retranslateUi(QMainWindow *chatWindow)
    {
    chatWindow->setWindowTitle(QApplication::translate("chatWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
    actionTyping->setText(QApplication::translate("chatWindow", "typing", 0, QApplication::UnicodeUTF8));
    pb_chatSend->setText(QApplication::translate("chatWindow", "Wy\305\233lij", 0, QApplication::UnicodeUTF8));
    toolBar->setWindowTitle(QApplication::translate("chatWindow", "toolBar", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class chatWindow: public Ui_chatWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHAT_H
