#include "ui_chat.h"
#include <QMainWindow>
#include <QDateTime>
#include <QCloseEvent>
#include <QSettings>
#include <QScrollBar>
#include <QTextDocument>

using namespace Ui;
class QTlenChatWindow: public QMainWindow
{
	Q_OBJECT
	public:
		chatWindow		ui;
		QTlenChatWindow(QWidget * parent = 0, Qt::WFlags f = 0 );
		~QTlenChatWindow(){};
		void setContactInfo(QString, QString);
		void setMyInfo(QString);
	private:
		QString 		jid;	//jid rozmówcy
		QString			nick;	//nick rozmówcy
		QString			myNick;
		QSettings		*settings;
		QString			myColor, myBg, chatColor, chatBg;
		QString			formatMessage(QDateTime, QString, QString, QString, QString);
		QScrollBar		*vertScroll;
	public slots:
		void			showMessage(QString, QDateTime);	//body i stamp
		void			sendMessage();
		void			setTyping(bool);
	signals:
		void			message(QString, QString);
		void			widgetClosed(QString);
	protected:
		void			closeEvent(QCloseEvent *event);
};

