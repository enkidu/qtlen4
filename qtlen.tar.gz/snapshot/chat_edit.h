#include <QtCore>
#include <QTextEdit>
#include <QKeyEvent>
class QTlenTextEdit: public QTextEdit
{
	Q_OBJECT
	public:
		QTlenTextEdit(QWidget * parent = 0);
		~QTlenTextEdit(){};
	protected:
		void			keyPressEvent( QKeyEvent * e );
	signals:
		void			returnPressed();
};