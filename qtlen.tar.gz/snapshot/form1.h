#include "ui_form1.h"
#include "qtlen.h"
#include "systrayicon.h"
#include "chat_manager.h"
#include "debug.h"
#include "edit_dialog.h"
#include "settings_dialog.h"
#include "info_edit.h"
#include <QMessageBox>
#include <QTextCodec>
#include <QMainWindow>
#include <QAbstractSocket>
#include <QCloseEvent>

using namespace Ui;
class QTlenGui: public QMainWindow
{
	Q_OBJECT
	public:
		MainWindow		ui;
		QTlenGui(QWidget * parent = 0, Qt::WFlags f = 0 );
		~QTlenGui(){};
		QTlen			*tlen;
		QTlenTrayIcon		*sysIcon;
		QSettings		*settings;
		QTlenRosterManager	*roster;
		QTlenDebugWindow	*debug;
		QTlenChatManager	*chats;
	public slots:
		void		displayError(QAbstractSocket::SocketError socketError);
		void		showMessage(QString, QString, QDateTime);
		void		respondForAuthenticated();
		void		respondForDisconnected();
		void		respondForConnecting();
		void		respondForServerConnect();
		void		respondForConnected();
		void		respondForRosterEnd();
		void		setStatus(int);
		void		setStatus();
		void		toggleVisible(QSystemTrayIcon::ActivationReason reason);
		void		appExit();
		void		displayAlert(QString);
		void		subscriptionRequestReceived(QString);
		void		openChat(QTreeWidgetItem*, int);
		void		menuActionInfo();
		void		menuActionChat();
		void		menuActionHistory();
		void		menuActionEdit();
		void		menuActionDelete();
		void		openConfigDialog();
		void		menuActionShowOfflines(bool);
		void		menuActionAdd();
		void		myInfoArrived(QTlenUserInfo);
	signals:
		void		sendMessage(QString, QString);
		void		setStatus(int, QString);
		void		subscribed(QString, bool);
	protected:
		void		closeEvent(QCloseEvent *event);
		
	//private slots:
};

