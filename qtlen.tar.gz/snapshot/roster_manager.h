#include <QtCore/QtCore>
#include <QTreeWidget>
#include <QLabel>
#include <QFont>
#include "defines.h"
#include "roster_box.h"
class RosterItem
{
	public:
		RosterItem() {}
		RosterItem(QString j, QString n, QString g, QString s)
			: jid(j), name(n), group(g), subscription(s), presence(Offline), desc(QString::null) {}
		RosterItem(const RosterItem& other)
		{
			jid		= other.jid;
			name		= other.name;
			group		= other.group;
			subscription	= other.subscription;
			desc		= other.desc;
			presence	= other.presence;
		}
		RosterItem& operator=(const RosterItem& other)
		{
			if (this == &other) return *this;
			jid		= other.jid;
			name		= other.name;
			group		= other.group;
			subscription	= other.subscription;
			desc		= other.desc;
			presence	= other.presence;
			return *this;
		}
		bool operator<(const RosterItem& other) const {
			if( name.compare( other.name , Qt::CaseInsensitive) < 0 )
				return true;
			else
				return false;
		}
		~RosterItem() {}
		
		QString		jid;
		QString		name;
		QString		group;
		QString		subscription;
		QTlenPresence	presence;
		QString 	desc;
		
};
class QTlenRosterManager: public QObject
{
	Q_OBJECT
	public:
		QTlenRosterManager(QTlenRosterBox *roster);
		~QTlenRosterManager(){};

		struct AddedItem
		{
			QString			jid;
			QTreeWidgetItem*	item;
		};
		struct AddedGroup
		{
			QString			group;
			QTreeWidgetItem*	item;
		};
		int			getIndexOf(QString);	//returns index, arguments: field, text
		QString			getJidOf(QString);	//uses index to find JID
		QString			getNameOf(QString);	//uses index to find nick
		QString			getGroupOf(QString);
		QString			getJidOf(QTreeWidgetItem*);
		int			getIndexOfGroup(QString);
		int			getIndexOfAddedGroup(QString group);
		QTreeWidgetItem*	getItemOfGroup(QString group);
	private:
		QList<RosterItem>	rosterItems;
		QList<AddedItem>	addedItems;
		QList<QString>		groups;
		QList<AddedGroup>	addedGroups;
		bool			dontShowOfflines;
		QTlenRosterBox		*rosterBox;
	public slots:
		void			beginRoster();
		void			addItem(QString, QString, QString, QString);		//jid, group, name, subscription
		void			deleteItem(QTreeWidgetItem*);
		void			presenceFrom(QString, QTlenPresence, QString);	//jid, type, description
		void			showRoster();
		void			showOfflines(bool);
};