#include "form1.h"
#include "sha1.h"

QTlenGui::QTlenGui(QWidget * parent, Qt::WFlags f):QMainWindow(parent, f)
{
	ui.setupUi(this);
	QTextCodec::setCodecForTr (QTextCodec::codecForName ("UTF-8"));
	QTextCodec::setCodecForLocale (QTextCodec::codecForName ("ISO8859-2"));
	setWindowTitle("QTlen4");

	settings = new QSettings(QDir::homePath() + "/.qtlen4/config", QSettings::IniFormat);

	sysIcon = new QTlenTrayIcon(0);
	sysIcon->show();

	roster = new QTlenRosterManager(ui.lv_roster);
	roster->showOfflines(1);

	tlen = new QTlen;
	tlen->setUserParams(settings->value("/connection/username").toString(), settings->value("/connection/password").toString());

	debug = new QTlenDebugWindow();
	if (settings->value("/advanced/xmlconsole", false).toBool())
		debug->show();
	ui.pbar_connecting->hide();
	chats = new QTlenChatManager(roster);
	chats->setMyInfo(settings->value("/preferences/nick", settings->value("/connection/username").toString()).toString());
	chats->setTrayIcon(sysIcon);

	ui.le_status->setText(settings->value("/status/last", "").toString());

	connect(ui.actionXMLConsole,	SIGNAL(toggled(bool)),					debug,		SLOT(setVisible(bool)));
	connect(ui.actionOpenChatsManager,	SIGNAL(activated()),				tlen,		SLOT(chatsGetTopLevelGroups()));
	connect(tlen,			SIGNAL(socketError(QAbstractSocket::SocketError)),	this,	SLOT(displayError(QAbstractSocket::SocketError)));
	connect(ui.actionMyInfo,	SIGNAL(activated()),					tlen,		SLOT(getInfoAboutMyself()));
	connect(ui.cb_status,		SIGNAL(currentIndexChanged(int)),			this,		SLOT(setStatus(int)));
	connect(ui.le_status,		SIGNAL(editingFinished()),				this,		SLOT(setStatus()));
	connect(this,			SIGNAL(setStatus(int, QString)),			tlen,		SLOT(setStatus(int, QString)));
	connect(tlen,			SIGNAL(receivedXml(QByteArray)),			debug,		SLOT(showXml(QByteArray)));
	connect(tlen,			SIGNAL(message(QString, QString, QDateTime)),		chats,		SLOT(showMessage(QString, QString, QDateTime)));
	connect(tlen,			SIGNAL(disconnected()),					this,		SLOT(respondForDisconnected()));
	connect(tlen,			SIGNAL(rosterInfoBegin()),				roster,		SLOT(beginRoster()));
	connect(tlen,			SIGNAL(rosterItem(QString, QString, QString, QString)),	roster,		SLOT(addItem(QString, QString, QString, QString)));
	connect(tlen,			SIGNAL(authenticated()),				this,		SLOT(respondForAuthenticated()));
	connect(tlen,			SIGNAL(presenceFrom(QString, QTlenPresence, QString)),	roster,		SLOT(presenceFrom(QString, QTlenPresence, QString)));
	connect(tlen,			SIGNAL(rosterInfoEnd()),				roster,		SLOT(showRoster()));
	connect(sysIcon,		SIGNAL(activated(QSystemTrayIcon::ActivationReason)),	this,	SLOT(toggleVisible(QSystemTrayIcon::ActivationReason)));
	connect(sysIcon,		SIGNAL(setStatus(int)),					ui.cb_status,	SLOT(setCurrentIndex(int)));
	connect(sysIcon,		SIGNAL(appExit()),					this,		SLOT(appExit()));
	connect(ui.actionExit,		SIGNAL(triggered()),					this,		SLOT(appExit()));
	connect(tlen,			SIGNAL(soundAlert(QString)),				this,		SLOT(displayAlert(QString)));
	connect(tlen,			SIGNAL(autorizationRequest(QString)),			this,		SLOT(subscriptionRequestReceived(QString)));
	connect(this,			SIGNAL(subscribed(QString, bool)),			tlen,		SLOT(setSubscribed(QString, bool)));
	connect(ui.lv_roster,		SIGNAL(itemDoubleClicked(QTreeWidgetItem*, int)),	this,		SLOT(openChat(QTreeWidgetItem*, int)));
	connect(chats,			SIGNAL(sendMessage(QString, QString)),			tlen,		SLOT(sendMessage(QString, QString)));
	connect(tlen,			SIGNAL(typingStarted(QString)),				chats,		SLOT(typingStarted(QString)));
	connect(tlen,			SIGNAL(typingStopped(QString)),				chats,		SLOT(typingStopped(QString)));
	connect(tlen,			SIGNAL(connecting()),					this,		SLOT(respondForConnecting()));
	connect(tlen,			SIGNAL(serverConnect()),				this,		SLOT(respondForServerConnect()));
	connect(tlen,			SIGNAL(connected()),					this,		SLOT(respondForConnected()));
	connect(tlen,			SIGNAL(rosterInfoEnd()),				this,		SLOT(respondForRosterEnd()));
	connect(ui.actionSettings,	SIGNAL(triggered()),					this,		SLOT(openConfigDialog()));
	connect(tlen,			SIGNAL(myInfoArrived(QTlenUserInfo)),			this,		SLOT(myInfoArrived(QTlenUserInfo)));
};

void QTlenGui::openConfigDialog()
{
	QTlenConfigDialog *config = new QTlenConfigDialog();
	config->show();
};

void QTlenGui::displayError(QAbstractSocket::SocketError socketError)
{
	switch (socketError) {
	case QAbstractSocket::RemoteHostClosedError:
	break;
	case QAbstractSocket::HostNotFoundError:
		QMessageBox::information(this, tr("Tlen.pl"),
                                  tr("The host was not found. Please check the "
                                     "host name and port settings."));
	break;
	case QAbstractSocket::ConnectionRefusedError:
		QMessageBox::information(this, tr("Tlen.pl"),
                                  tr("The connection was refused by the peer. "
                                     "Make sure the fortune server is running, "
                                     "and check that the host name and port "
                                     "settings are correct."));
	break;
     }
};

void QTlenGui::displayAlert(QString jid)
{
	QMessageBox::information(this, tr("QTlen4"), "User " + jid + " wants you to be online");
};

void QTlenGui::subscriptionRequestReceived(QString jid)
{
	int msg = QMessageBox::question(this, tr("Autorization request"), "Użytkownik " + jid + " chce dodać Cię do swojej listy kontaktów", QMessageBox::Yes, QMessageBox::No);
	if( msg == QMessageBox::Yes )
	{
		emit subscribed(jid, true);
	}
	else
	{
		emit subscribed(jid, false);
	}
};

void QTlenGui::showMessage(QString from, QString body, QDateTime timestamp)
{
	sysIcon->showMessage("Message from " + from, body);
};

void QTlenGui::respondForAuthenticated()
{
	setStatus();
	ui.pbar_connecting->setFormat(tr("Pobieranie kontaktów..."));
	ui.pbar_connecting->setValue(3);
};

void QTlenGui::setStatus(int code)
{
	QByteArray status[] = 
	{
		"online",
		"chatty",
		"away",
		"extended away",
		"do not disturb",
		"invisible",
		"offline"
	};
	emit setStatus(code, ui.le_status->text());
	sysIcon->setStatusIcon(ui.cb_status->currentIndex());
	sysIcon->setToolTip("<b>You are now " + status[code] + "</b><br>" + ui.le_status->text().toAscii());
}

void QTlenGui::setStatus()
{	
	QByteArray status[] = 
	{
		"online",
		"chatty",
		"away",
		"extended away",
		"do not disturb",
		"invisible",
		"offline"
	};
	emit setStatus(ui.cb_status->currentIndex(), ui.le_status->text());
	settings->setValue("/status/last", ui.le_status->text());
	sysIcon->setToolTip("<b>You are now " + status[ui.cb_status->currentIndex()] + "</b><br>" + ui.le_status->text().toAscii());
}

void QTlenGui::respondForDisconnected()
{
	ui.lv_roster->clear();
	sysIcon->showMessage("QTlenCore Message", "You are now disconnected");
};

void QTlenGui::toggleVisible(QSystemTrayIcon::ActivationReason reason)
{
	if (reason == QSystemTrayIcon::Trigger)
	{
		if (this->isVisible())
			this->hide();
		else
			this->show();
	}
};

void QTlenGui::closeEvent(QCloseEvent *event)
{
	event->ignore();
	this->hide();
};

void QTlenGui::appExit()
{
	emit setStatus(0, ui.le_status->text());
	exit(0);
};

void QTlenGui::openChat(QTreeWidgetItem* item, int unused)
{
	chats->openChat(roster->getJidOf(item));
};

void QTlenGui::respondForConnecting()
{
	ui.pbar_connecting->show();
	ui.pbar_connecting->setFormat(tr("Ustalanie adresu serwera..."));
	ui.pbar_connecting->setValue(0);
};
void QTlenGui::respondForServerConnect()
{
	ui.pbar_connecting->setFormat(tr("Łączenie z serwerem..."));
	ui.pbar_connecting->setValue(1);
};
void QTlenGui::respondForConnected()
{
	ui.pbar_connecting->setFormat(tr("Autoryzacja..."));
	ui.pbar_connecting->setValue(2);
};
void QTlenGui::respondForRosterEnd()
{
	ui.pbar_connecting->setValue(4);
	ui.pbar_connecting->hide();
};

void QTlenGui::menuActionInfo()
{
	tlen->getInfoAbout(roster->getJidOf(ui.lv_roster->currentItem()));
};

void QTlenGui::menuActionChat()
{
	chats->openChat(roster->getJidOf(ui.lv_roster->currentItem()));
};

void QTlenGui::menuActionHistory()
{
	//history->showChatsWith(roster->getJidOf(ui.lv_roster->currentItem()->text()));
};

void QTlenGui::menuActionEdit()
{
	QString jid = roster->getJidOf(ui.lv_roster->currentItem());
	QTlenUserEdit *edit = new QTlenUserEdit(0, jid , roster->getNameOf(jid), roster->getGroupOf(jid));
	connect(edit,	SIGNAL(saveItem(QString, QString, QString)),	tlen,	SLOT(saveRosterItem(QString, QString, QString)));
	edit->show();
};

void QTlenGui::menuActionDelete()
{	
	int msg = QMessageBox::question(this, tr("Potwierdzenie"), QString::fromUtf8("Czy na pewno chcesz usunąć wybrany kontakt?"), QMessageBox::Yes, QMessageBox::No);
	if( msg == QMessageBox::Yes )
	{
		tlen->deleteUser(roster->getJidOf(ui.lv_roster->currentItem()));
		roster->deleteItem(ui.lv_roster->currentItem());
	}
};

void QTlenGui::menuActionShowOfflines(bool yesno)
{
	roster->showOfflines(yesno);
};

void QTlenGui::menuActionAdd()
{
	QTlenUserEdit *edit = new QTlenUserEdit(0, "" , "", "");
	connect(edit,	SIGNAL(saveItem(QString, QString, QString)),	tlen,	SLOT(saveRosterItem(QString, QString, QString)));
	edit->show();
};

void QTlenGui::myInfoArrived(QTlenUserInfo info)
{
	QTlenPubdirEdit *infoWindow = new QTlenPubdirEdit(0);
	infoWindow->setInfo(info);
	infoWindow->show();
	connect(infoWindow, SIGNAL(saveInfo(QTlenUserInfo)), tlen, SLOT(saveMyInfo(QTlenUserInfo)));
};