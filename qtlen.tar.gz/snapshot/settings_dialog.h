#ifndef SETTINGS_DIALOG_H
#define SETTINGS_DIALOG_H

#include "ui_config.h"
#include <QToolBox>
#include <QSettings>
#include <QCloseEvent>
#include <QtCore>
#include <QColorDialog>

using namespace Ui;
class QTlenConfigDialog: public QToolBox
{
	Q_OBJECT
	public:
		configDialog			ui;
		QTlenConfigDialog(QWidget * parent = 0);
		~QTlenConfigDialog(){};
	private slots:
		void		setMyColor();
		void		setMyBg();
		void		setChatColor();
		void		setChatBg();
	private:
		QSettings		*settings;
		bool			changed;
	protected:
		void			closeEvent(QCloseEvent *event);
	signals:
		void			configChanged();
};

#endif