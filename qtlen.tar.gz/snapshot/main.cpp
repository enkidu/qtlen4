#include <QApplication>
#include "form1.h"

int main(int argc, char *argv[])
{
        QApplication app(argc, argv);
	app.setQuitOnLastWindowClosed(false);
        QTlenGui window(0, 0);
	window.show();
        return app.exec();
}