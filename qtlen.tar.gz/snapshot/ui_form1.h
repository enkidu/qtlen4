/********************************************************************************
** Form generated from reading ui file 'form1.ui'
**
** Created: Thu Jan 29 07:39:04 2009
**      by: Qt User Interface Compiler version 4.4.3
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_FORM1_H
#define UI_FORM1_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QLineEdit>
//#include <QtGui/QWidget>
#include "roster_box.h"
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QProgressBar>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionSettings;
    QAction *actionMyInfo;
    QAction *actionExit;
    QAction *actionAboutQTlen;
    QAction *actionAboutQt;
    QAction *actionOpenChatsManager;
    QAction *actionXMLConsole;
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QTlenRosterBox *lv_roster;
    QLineEdit *le_status;
    QComboBox *cb_status;
    QProgressBar *pbar_connecting;
    QMenuBar *menuBar;
    QMenu *menuMenu;
    QMenu *menuPomoc;
    QMenu *menuZaawansowane;

    void setupUi(QMainWindow *MainWindow)
    {
    if (MainWindow->objectName().isEmpty())
        MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
    MainWindow->resize(328, 388);
    actionSettings = new QAction(MainWindow);
    actionSettings->setObjectName(QString::fromUtf8("actionSettings"));
    QIcon icon;
    icon.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/configure.png")), QIcon::Normal, QIcon::Off);
    actionSettings->setIcon(icon);
    actionMyInfo = new QAction(MainWindow);
    actionMyInfo->setObjectName(QString::fromUtf8("actionMyInfo"));
    QIcon icon1;
    icon1.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/user-properties.png")), QIcon::Normal, QIcon::Off);
    actionMyInfo->setIcon(icon1);
    actionExit = new QAction(MainWindow);
    actionExit->setObjectName(QString::fromUtf8("actionExit"));
    actionOpenChatsManager =  new QAction(MainWindow);
    actionOpenChatsManager->setObjectName(QString::fromUtf8("actionOpenChatsManager"));
    QIcon icon2;
    icon2.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/application-exit.png")), QIcon::Normal, QIcon::Off);
    actionExit->setIcon(icon2);
    actionAboutQTlen = new QAction(MainWindow);
    actionAboutQTlen->setObjectName(QString::fromUtf8("actionAboutQTlen"));
    actionAboutQt = new QAction(MainWindow);
    actionAboutQt->setObjectName(QString::fromUtf8("actionAboutQt"));
    QIcon icon3;
    icon3.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/view-user-offline-kopete.png")), QIcon::Normal, QIcon::Off);
    actionXMLConsole = new QAction(MainWindow);
    actionXMLConsole->setObjectName(QString::fromUtf8("actionXMLConsole"));
    actionXMLConsole->setCheckable(true);
    QIcon icon4;
    icon4.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/preferences-plugin-script.png")), QIcon::Normal, QIcon::Off);
    actionXMLConsole->setIcon(icon4);
    centralwidget = new QWidget(MainWindow);
    centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
    verticalLayout = new QVBoxLayout(centralwidget);
    verticalLayout->setSpacing(0);
    verticalLayout->setMargin(0);
    verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
    lv_roster = new QTlenRosterBox(centralwidget);
    lv_roster->setObjectName(QString::fromUtf8("lv_roster"));
    QFont font;
    font.setBold(false);
    font.setWeight(50);
    lv_roster->setFont(font);
    //lv_roster->setViewMode(QListView::ListMode);
    lv_roster->setSortingEnabled(false);
    lv_roster->setHeaderHidden(true);

    verticalLayout->addWidget(lv_roster);

    le_status = new QLineEdit(centralwidget);
    le_status->setObjectName(QString::fromUtf8("le_status"));
    le_status->setMaxLength(100);

    verticalLayout->addWidget(le_status);
    QIcon icon11;
    icon11.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/16x16/chatty.png")), QIcon::Normal, QIcon::Off);
    cb_status = new QComboBox(centralwidget);
    QIcon icon5;
    icon5.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/16x16/online.png")), QIcon::Normal, QIcon::Off);
    cb_status->addItem(icon5, QString());
    QIcon icon6;
    icon6.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/16x16/away.png")), QIcon::Normal, QIcon::Off);
    cb_status->addItem(icon11, QString());
    cb_status->addItem(icon6, QString());
    QIcon icon7;
    icon7.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/16x16/xa.png")), QIcon::Normal, QIcon::Off);
    cb_status->addItem(icon7, QString());
    QIcon icon8;
    icon8.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/16x16/dnd.png")), QIcon::Normal, QIcon::Off);
    cb_status->addItem(icon8, QString());
    QIcon icon9;
    icon9.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/16x16/invisible.png")), QIcon::Normal, QIcon::Off);
    cb_status->addItem(icon9, QString());
    QIcon icon10;
    icon10.addPixmap(QPixmap(QString::fromUtf8(":/icons/icons/16x16/offline.png")), QIcon::Normal, QIcon::Off);

    cb_status->addItem(icon10, QString());
    cb_status->setObjectName(QString::fromUtf8("cb_status"));

    verticalLayout->addWidget(cb_status);

    pbar_connecting = new QProgressBar(centralwidget);
    pbar_connecting->setObjectName(QString::fromUtf8("pbar_connecting"));
    pbar_connecting->setMaximum(4);
    pbar_connecting->setValue(0);

    verticalLayout->addWidget(pbar_connecting);

    MainWindow->setCentralWidget(centralwidget);
    menuBar = new QMenuBar(MainWindow);
    menuBar->setObjectName(QString::fromUtf8("menuBar"));
    menuBar->setGeometry(QRect(0, 0, 328, 25));
    menuMenu = new QMenu(menuBar);
    menuMenu->setObjectName(QString::fromUtf8("menuMenu"));
    menuPomoc = new QMenu(menuBar);
    menuPomoc->setObjectName(QString::fromUtf8("menuPomoc"));
    menuZaawansowane = new QMenu(menuBar);
    menuZaawansowane->setObjectName(QString::fromUtf8("menuZaawansowane"));
    MainWindow->setMenuBar(menuBar);

    menuBar->addAction(menuMenu->menuAction());
    menuBar->addAction(menuZaawansowane->menuAction());
    menuBar->addAction(menuPomoc->menuAction());
    menuMenu->addAction(actionSettings);
    menuMenu->addAction(actionMyInfo);
    menuMenu->addAction(actionOpenChatsManager);
    menuMenu->addSeparator();
    menuMenu->addAction(actionExit);
    menuPomoc->addAction(actionAboutQTlen);
    menuPomoc->addAction(actionAboutQt);
    menuZaawansowane->addAction(actionXMLConsole);

    retranslateUi(MainWindow);

    cb_status->setCurrentIndex(6);


    QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
    MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
    actionSettings->setText(QApplication::translate("MainWindow", "&Ustawienia", 0, QApplication::UnicodeUTF8));
    actionMyInfo->setText(QApplication::translate("MainWindow", "Moje &Dane", 0, QApplication::UnicodeUTF8));
    actionOpenChatsManager->setText(QApplication::translate("MainWindow", "Czaty Tlen.pl", 0, QApplication::UnicodeUTF8));
    actionExit->setText(QApplication::translate("MainWindow", "Za&ko\305\204cz", 0, QApplication::UnicodeUTF8));
    actionAboutQTlen->setText(QApplication::translate("MainWindow", "O &QTlen4", 0, QApplication::UnicodeUTF8));
    actionAboutQt->setText(QApplication::translate("MainWindow", "O Q&t", 0, QApplication::UnicodeUTF8));
    actionXMLConsole->setText(QApplication::translate("MainWindow", "Podgl\304\205d komunikacji z serwerem", 0, QApplication::UnicodeUTF8));

#ifndef QT_NO_TOOLTIP
    le_status->setToolTip(QApplication::translate("MainWindow", "Wiadomo\305\233\304\207 statusu", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP

    cb_status->setItemText(0, QApplication::translate("MainWindow", "Online", 0, QApplication::UnicodeUTF8));
    cb_status->setItemText(1, QApplication::translate("MainWindow", "Chatty", 0, QApplication::UnicodeUTF8));
    cb_status->setItemText(2, QApplication::translate("MainWindow", "Away", 0, QApplication::UnicodeUTF8));
    cb_status->setItemText(3, QApplication::translate("MainWindow", "Extended Away", 0, QApplication::UnicodeUTF8));
    cb_status->setItemText(4, QApplication::translate("MainWindow", "Do not disturb", 0, QApplication::UnicodeUTF8));
    cb_status->setItemText(5, QApplication::translate("MainWindow", "Invisible", 0, QApplication::UnicodeUTF8));
    cb_status->setItemText(6, QApplication::translate("MainWindow", "Offline", 0, QApplication::UnicodeUTF8));

    pbar_connecting->setFormat(QApplication::translate("MainWindow", "connecting", 0, QApplication::UnicodeUTF8));
    menuMenu->setTitle(QApplication::translate("MainWindow", "&Menu", 0, QApplication::UnicodeUTF8));
    menuPomoc->setTitle(QApplication::translate("MainWindow", "Pomo&c", 0, QApplication::UnicodeUTF8));
    menuZaawansowane->setTitle(QApplication::translate("MainWindow", "Zaawansowane", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORM1_H
